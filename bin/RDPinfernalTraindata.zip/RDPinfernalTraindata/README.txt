RDP Infernal Training Set README file 

Last update: 02/18/2011
contact: RDP staff at rdpstaff@msu.edu
        James R. Cole at colej@msu.edu


This directory contains the COPYRIGHT and two hand-curated alignment files: bacteria16S_508_mod5.stk for Bacteria, and archaea79_corrEnd_mod2.stk for Archaea. The latest Infernal software can be downloaded from the Infernal website (http://infernal.janelia.org/).

We spent some effort to tune the Infernal and found certain entropy value that work best for these training sets. We settled on the following to build the model for Infernal version 1.0: "cmbuild --rf --ere 1.4"

The parameters we use for alignment are "cmalign --hbanded --sub"

Tips: Infernal only works with the sequences in the forward orientation. Negative bits saved scores from infernal usually indicate something wrong with the input sequence, reverse orientation, non 16S rRNA bacterial and archaeal sequences or sequences of very low-quality. We normally discard sequences returned with negative bits saved scores from the final alignment.   

If you find these data useful to you, please cite "The Ribosomal Database Project: improved alignments and new tools for rRNA analysis" Nucleic Acids Res. 37 (Database issue):D141-D145 (http://nar.oxfordjournals.org/content/37/suppl_1/D141.full). 